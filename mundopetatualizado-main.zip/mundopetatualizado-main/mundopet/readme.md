Luciel Carvalho
Tiago de Lima
Nicolas Rabelo
Samuel Sales
Emanoele Candido
Daniel Gomes